function y=truedf2nd(x)
% Xing Jin and Javier Lobato, modified 02/14/18
% The true analytic value of the 2nd derivative of sin(x) is -sin(x)
y = -sin(x);
