function y=truedf3rd(x)
% Xing Jin and Javier Lobato, modified 02/14/18
% The true analytic value of the 3rd derivative of sin(x) is -cos(x)
y = -cos(x);